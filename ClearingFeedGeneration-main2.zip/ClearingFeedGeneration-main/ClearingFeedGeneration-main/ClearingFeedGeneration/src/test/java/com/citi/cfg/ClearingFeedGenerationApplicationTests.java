package com.citi.cfg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClearingFeedGenerationApplicationTests {

	@Test
	void contextLoads() {
	}

}
