package com.citi.cfg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClearingFeedGenerationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClearingFeedGenerationApplication.class, args);
	}
}
